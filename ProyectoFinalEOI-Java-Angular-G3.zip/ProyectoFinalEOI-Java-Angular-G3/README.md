# g3
Proyecto final EOI - Angular
Integrantes:
Daniel Jaén Márquez,
Victoria Rodenas Pico
