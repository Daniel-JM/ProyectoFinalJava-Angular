export const environment = {
  BACKEND_URL:'URLBACK',
  production: true
};