import { Component, Input, OnInit } from '@angular/core';
import { Usuarios } from 'src/app/clases/usuarios';
import { appService } from 'src/app/servicios/app.service';
import { HttpClientModule } from "@angular/common/http";
import { Articulos } from 'src/app/clases/articulos';
import { Pedidos } from 'src/app/clases/pedidos';
import { stringify } from '@angular/compiler/src/util';
import { Router } from '@angular/router';
import { textChangeRangeIsUnchanged } from 'typescript';
import { Cantidad } from 'src/app/clases/cantidad';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  @Input()
  usuarioLogeado: Usuarios = new Usuarios()

  usuarioSeleccionado: boolean = false
  articuloSeleccionado: boolean = false
  pedidoSeleccionado: boolean = false

  filtroUsuarios: string = ""
  filtroArticulos: string = ""
  filtroPedidos: string = ""

  //verificacion de operacion realizada
  operacionRealizada: boolean = false;
  //deshabilitar lista 
  listaUOn: boolean = false;
  listaAOn: boolean = false;
  listaPOn: boolean = false;

  //deshabilitar Crear nuevo
  crearUser: boolean = false;
  crearArtic: boolean = false;
  nuevoPedido: boolean = false;

  //deshabilitar Actualizar
  actualizarUser: boolean = false
  actualizarArt: boolean = false;
  actualizarPed: boolean = false;

  //datos de Inputs de Crear 
  //Usuario
  nombreUsuario: string;
  contrasenyaUsuario: string;
  //Articulo
  nombreArticulo: string
  precioArticulo: number
  stockArticulo: number
  //Pedido
  nombrePedido: string;
  fecha: string;
  nombreArticuloPedido: string
  totalPrice: number
  unidadesArticuloPedido: number
  priceTotalPedido: number = 0

  //datos de Inputs de actualizar 
  //Usuario
  idUsuarioUpdate: number
  nombreUsuarioUpdate: string;
  contrasenyaUsuarioUpdate: string;
  //Articulo  
  idArticuloUpdate: number
  nombreArticuloUpdate: string
  precioArticuloUpdate: number
  stockArticuloUpdate: number
  //Pedido
  //-------------------------------------------------------------------------------------
  idPedidoUpdate: number
  nombrePedidoUpdate: string
  fechaPedidoUpdate: string
  articulo: Articulos

  //declaracion arrays
  listaUsuarios: Array<Usuarios>;
  listaArticulos: Array<Articulos>;
  listaPedidos: Array<Pedidos>;
  // listaArticulosAgregados: Array<ArticuloAgregado>

  lista: Array<Articulos>

  //lista de articulos anyadidos a pedidos
  listaCantidad: Array<Cantidad>;

  constructor(private servicio: appService, private ruta: Router) {

    //inicializacion arrays
    this.listaUsuarios = new Array<Usuarios>();
    this.listaArticulos = new Array<Articulos>();
    this.listaPedidos = new Array<Pedidos>();
    this.listaCantidad = new Array<Cantidad>();
    this.lista = new Array<Articulos>()
    // this.listaArticulosAgregados = new Array<ArticuloAgregado>();
  }

  ngOnInit(): void {
    this.usuarioLogeado = this.servicio.usuarioLogeado;
    this.cargarUsuarios()
    this.cargarArticulos()
    this.cargarPedidos()
  }

  seleccionarUsuarios() {
    this.usuarioSeleccionado = true;
    this.articuloSeleccionado = false;
    this.pedidoSeleccionado = false;

    //deshabilitar listas ver todos
    this.listaUOn = false;
    this.crearUser = false;
    this.nuevoPedido = false;

    //operacion realizada

    this.operacionRealizada = false;

    //deshabilitar articulos    
    this.listaAOn = false;
    this.crearArtic = false;
    this.actualizarArt = false;
    //deshabilitar pedidos
    this.nuevoPedido = false;
    this.listaPOn = false
  }
  seleccionarArticulos() {
    this.usuarioSeleccionado = false;
    this.articuloSeleccionado = true;
    this.pedidoSeleccionado = false;

    //deshabilitar usuarios
    this.listaUOn = false;
    this.crearUser = false;
    //deshabilitar articulos    
    this.listaAOn = false;
    this.crearArtic = false;
    this.actualizarArt = false;
    //deshabilitar pedidos
    this.nuevoPedido = false;
    this.listaPOn = false

    //operacion realizada
    this.operacionRealizada = false;

  }
  seleccionarPedidos() {
    this.usuarioSeleccionado = false;
    this.articuloSeleccionado = false;
    this.pedidoSeleccionado = true;

    //deshabilitar usuarios
    this.listaUOn = false;
    this.crearUser = false;
    //deshabilitar articulos    
    this.listaAOn = false;
    this.crearArtic = false;
    this.actualizarArt = false;
    //deshabilitar pedidos
    this.nuevoPedido = false;
    this.listaPOn = false

    //operacion realizada
    this.operacionRealizada = false;

  }

  cerrar() {
    this.usuarioSeleccionado = false;
    this.articuloSeleccionado = false;
    this.pedidoSeleccionado = false;

    this.listaUOn = false;
    this.crearUser = false
    this.actualizarUser = false;

    this.listaAOn = false;
    this.crearArtic = false;
    this.actualizarArt = false;

    this.nuevoPedido = false;
    this.listaPOn = false

    //operacion realizada
    this.operacionRealizada = false;
  }

  logOut() {
    this.usuarioLogeado.name = "";
    this.usuarioLogeado.password = "";
    this.navegarFormulario()
  }

  navegarFormulario() {
    this.ruta.navigate([''])
  }

  //cargar usuarios
  cargarUsuarios() {
    this.servicio.getUsuarios().subscribe((ok: Array<Usuarios>) => {
      this.listaUsuarios = ok;
    })
  }
  cargarArticulos() {
    this.servicio.getArticulos().subscribe((ok: Array<Articulos>) => {
      this.listaArticulos = ok;
    })
  }
  cargarPedidos() {
    this.servicio.getPedidos().subscribe((ok: Array<Pedidos>) => {
      this.listaPedidos = ok;
    })
  }

  //Mostrar usuarios
  mostrarUsuarios() {
    this.servicio.getUsuarios().subscribe((ok: Array<Usuarios>) => {

      console.log(ok);
      this.listaUsuarios = ok;
      this.listaUOn = true;
      this.crearUser = false;
      this.actualizarUser = false;
    });
  }

  llamarCrearUsuario() {
    this.crearUser = true;
    this.listaUOn = false;
    this.actualizarUser = false;
    //operacion realizada
    this.operacionRealizada = false;
  }

  llamarNuevoPedido() {
    this.nuevoPedido = true;
    this.listaPOn = false;
    //operacion realizada
    this.operacionRealizada = false;
  }

  /*mostrar articulos en Pedidos*/
  mostrarArticulosPedido() {
    this.servicio.getArticulos().subscribe((ok: Array<Articulos>) => {

      console.log(ok);
      this.listaArticulos = ok;

    });
  }

  llamadaActualizadUsuario(usuario: Usuarios) {
    this.actualizarUser = true;
    this.listaUOn = false;
    //operacion realizada
    this.operacionRealizada = false;

    this.idUsuarioUpdate = usuario.id
    this.nombreUsuarioUpdate = usuario.name
    this.contrasenyaUsuarioUpdate = usuario.password
  }

  crearUsuario() {
    let usuario: Usuarios = new Usuarios();
    usuario.name = this.nombreUsuario;
    usuario.password = this.contrasenyaUsuario;

    if (this.nombreUsuario != null && this.contrasenyaUsuario != null) {
      this.servicio.addUsuario(usuario).subscribe(us => this.listaUsuarios.push(us));
      //operacion realizada
      this.operacionRealizada = true;
    }

    else {
      alert("intoduzca un usuario valido");
    }
  }

  actualizarUsuario() {

    let usuarioUpdate: Usuarios = {
      id: this.idUsuarioUpdate,
      name: this.nombreUsuarioUpdate,
      password: this.contrasenyaUsuarioUpdate,
      image: "http://placekitten.com/200/100"
    }
    this.servicio.updateUsuario(usuarioUpdate).subscribe();

    //operacion realizada
    this.operacionRealizada = true;
  }

  borrarUsuario(usuario: Usuarios) {
    this.servicio.deleteUsuario(usuario.id)
      .subscribe(
        data => { this.listaUsuarios = this.listaUsuarios.filter(borrar => { return borrar.id !== usuario.id }) }
      )
  }

  //total usuarios
  totalUsers() {
    return this.listaUsuarios.reduce((prev, current) => prev + current.cantidad, 0)
  }
  totalArticulos() {
    return this.listaArticulos.reduce((prev, current) => prev + current.cantidad, 0)
  }
  totalPedidos() {
    return this.listaPedidos.reduce((prev, current) => prev + current.cantidad, 0)
  }

  //Articulos
  //Mostrar Articulos
  mostrarArticulos() {
    this.servicio.getArticulos().subscribe((ok: Array<Articulos>) => {

      console.log(ok);
      this.listaArticulos = ok;
      this.listaAOn = true;
      this.crearArtic = false;
      this.actualizarArt = false;
    });
  }

  llamarCrearArticulo() {
    this.listaAOn = false;
    this.crearArtic = true;
    this.actualizarArt = false;
    this.operacionRealizada = false;
  }

  crearArticulo() {
    if (this.nombreArticulo != null && this.precioArticulo != null) {
      let articulo: Articulos = new Articulos();
      articulo.name = this.nombreArticulo;
      articulo.price = this.precioArticulo;
      articulo.stock = this.stockArticulo;
      articulo.pedido = 0
      this.servicio.addArticulo(articulo).subscribe(art => this.listaArticulos.push(art));
      this.operacionRealizada = true;
    } else {
      alert("El nombre o precio no pueden estar vacios")
    }
  }

  llamadaActualizarArticulo(articulo: Articulos) {
    this.actualizarArt = true;
    this.listaAOn = false;
    this.operacionRealizada = false;

    this.idArticuloUpdate = articulo.id
    this.nombreArticuloUpdate = articulo.name
    this.precioArticuloUpdate = articulo.price
    this.stockArticuloUpdate = articulo.stock
  }

  actualizarArticulo() {

    let articuloUpdate: Articulos = {
      id: this.idArticuloUpdate,
      name: this.nombreArticuloUpdate,
      price: this.precioArticuloUpdate,
      stock: this.stockArticuloUpdate,
      image: "http://placekitten.com/200/200"

    }
    this.servicio.updateArticulo(articuloUpdate).subscribe();
    this.actualizarArt = true;
    this.operacionRealizada = true;
  }

  borrarArticulo(articulo: Articulos) {
    this.servicio.deleteArticulo(articulo.id)
      .subscribe(
        data => { this.listaArticulos = this.listaArticulos.filter(borrar => { return borrar.id !== articulo.id }) }
      )
  }

  //PEDIDOS
  crearPedido() {

    let pedido: Pedidos = new Pedidos();

    if (this.nombrePedido != null && this.fecha != null) {

      pedido.name = this.nombrePedido;
      pedido.date = this.fecha;
      pedido.listaArti = this.listaCantidad;
      pedido.price = this.priceTotalPedido
      this.servicio.addPedido(pedido).subscribe(pedido => this.listaPedidos.push(pedido))
      for (let i = 0; i < this.listaCantidad.length; i++) {
        this.listaCantidad.pop();
      }

      //operacion realizada
      this.operacionRealizada = true;

    }
  }

  //Funcion para agregar un item a los pedidos en Cantidad
  anyadirArticuloP(articulo: Articulos) {

    let value = (<HTMLSelectElement>document.getElementById('unidad')).value;

    let cantidad: Cantidad = new Cantidad();
    cantidad.unidades = parseInt(value);
    cantidad.articulo = articulo;
    this.nombreArticuloPedido = cantidad.articulo.name

    let sumaTotal: number = articulo.price * cantidad.unidades;
    cantidad.precioTotal = sumaTotal;
    let resultado: number;
    resultado = articulo.stock - parseInt(value);
    if (resultado >= 0) {
      this.totalPrice = articulo.price * articulo.cantidad
      articulo.pedido = articulo.pedido + 1
      this.lista.push(articulo);
      articulo.pedido = articulo.pedido + 1;
      articulo.stock = articulo.stock - parseInt(value);
      this.servicio.updateArticulo(articulo).subscribe();

      //declaracion cantidad

      let resultado: number;

      let cantidad: Cantidad = new Cantidad();
      cantidad.unidades = parseInt(value);
      cantidad.articulo = articulo;


      let sumaTotal: number = articulo.price * cantidad.unidades;
      cantidad.precioTotal = sumaTotal;
      this.priceTotalPedido += sumaTotal

      this.servicio.addCantidad(cantidad).subscribe(ok => this.listaCantidad.push(ok));
    }
    else {
      alert("No tenemos suficiente existencias")
    }
  }

  mostrarPedidos() {
    this.servicio.getPedidos().subscribe((ok: Array<Pedidos>) => {

      console.log(ok);
      this.listaPedidos = ok;
      this.listaPOn = true;
      this.nuevoPedido = false;
      this.actualizarPed = false;
    });
  }

  llamadaActualizarPedido(pedido: Pedidos) {
    // this.actualizarPed = true;
    // this.listaPOn = false;

    // this.idPedidoUpdate = pedido.id
    // this.nombrePedidoUpdate = pedido.name
    // this.fechaPedidoUpdate = pedido.date
    // this.articulo = pedido.articulo[]
  }

  actualizarPedido() {

    // let pedidoUpdate: Pedidos = {
    //   // id: this.idArticuloUpdate,
    //   // name: this.nombreArticuloUpdate,
    //   // date: this.precioArticuloUpdate,
    //   // articulo:

    // }
    // this.servicio.updateArticulo(pedidoUpdate).subscribe();
  }

  borrarPedido(pedido: Pedidos) {
    this.servicio.deletePedido(pedido.id)
      .subscribe(
        data => { this.listaPedidos = this.listaPedidos.filter(borrar => { return borrar.id !== pedido.id }) }
      )
  }


}