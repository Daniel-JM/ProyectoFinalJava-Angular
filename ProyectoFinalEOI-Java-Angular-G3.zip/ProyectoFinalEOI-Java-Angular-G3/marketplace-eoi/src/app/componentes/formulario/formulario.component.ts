import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { appService } from 'src/app/servicios/app.service';
import { Usuarios } from '../../clases/usuarios'

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit {


  formularioLogin: FormGroup;
  usuarioLogeado: Usuarios = new Usuarios()
  usuarios: Usuarios[]

  constructor(private servicio: appService, private ruta: Router, private fb: FormBuilder) {
    this.formularioLogin = fb.group(
      {
        "name": ['', Validators.required],
        "password": ['', Validators.required]
      }
    );
    this.servicio.getUsuarios().subscribe(
      (ok: Array<Usuarios>) => {
        this.usuarios = ok;
      }
    )
  }

  validarUsuario() {
    if (this.formularioLogin.valid) {
      let encontrado = this.usuarios.find(usuario => (usuario.name == this.usuarioLogeado.name) && (usuario.password == this.usuarioLogeado.password))
      if (encontrado) {
        this.usuarioLogeado = encontrado
        this.servicio.usuarioLogeado = this.usuarioLogeado
        this.navegarDashboard();
      } else {
       alert("Usuario o contraseña incorrecto");
      }
    } else {
      alert("El nombre o contraseña tiene un formato incorrecto")
    }
  }


  navegarDashboard() {
    this.ruta.navigate(['/dashboard'])
  }

  ngOnInit(): void {
  }

}
