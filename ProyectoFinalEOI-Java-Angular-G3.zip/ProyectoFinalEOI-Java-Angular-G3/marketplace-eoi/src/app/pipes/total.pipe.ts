import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'total'
})
export class TotalPipe implements PipeTransform {


   transform(value: Array<any>, ...args: unknown[]): unknown {
    
    return value.reduce((prev, current)=>prev+current.cantidad,0);

  }

}
