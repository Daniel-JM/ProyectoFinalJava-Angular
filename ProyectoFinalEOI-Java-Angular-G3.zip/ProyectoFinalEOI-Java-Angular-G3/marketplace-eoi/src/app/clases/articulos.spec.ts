import { Articulos } from './articulos';

describe('Articulos', () => {
  it('should create an instance', () => {
    expect(new Articulos()).toBeTruthy();
  });
});
