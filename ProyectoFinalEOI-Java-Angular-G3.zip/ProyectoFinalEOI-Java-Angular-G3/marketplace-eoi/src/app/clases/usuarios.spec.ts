import { Usuarios } from './usuarios';

describe('Usuarios', () => {
  it('should create an instance', () => {
    expect(new Usuarios()).toBeTruthy();
  });
});
