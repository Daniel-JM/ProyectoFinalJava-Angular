import { Cantidad } from './cantidad';

describe('Cantidad', () => {
  it('should create an instance', () => {
    expect(new Cantidad()).toBeTruthy();
  });
});
