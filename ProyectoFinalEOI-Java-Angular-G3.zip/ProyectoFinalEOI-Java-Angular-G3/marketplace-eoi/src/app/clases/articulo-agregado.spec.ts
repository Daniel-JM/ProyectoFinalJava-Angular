import { ArticuloAgregado } from './articulo-agregado';

describe('ArticuloAgregado', () => {
  it('should create an instance', () => {
    expect(new ArticuloAgregado()).toBeTruthy();
  });
});
