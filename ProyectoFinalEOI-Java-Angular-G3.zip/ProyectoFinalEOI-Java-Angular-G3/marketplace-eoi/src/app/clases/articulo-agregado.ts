export class ArticuloAgregado {
    name: string;
    totalPrice: number;
    unidades: number;
}
