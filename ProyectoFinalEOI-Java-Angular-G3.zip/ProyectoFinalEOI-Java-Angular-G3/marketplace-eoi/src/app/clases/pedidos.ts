import { Cantidad } from "./cantidad"

export class Pedidos {
    id?: number
    name: string
    price: number
    date: string
    cantidad: number = 1
    
    listaArti:Array<Cantidad>

   
}