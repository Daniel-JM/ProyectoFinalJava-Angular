import { Articulos } from "./articulos";

export class Cantidad {

    id?: number;
    articulo: Articulos;
    unidades: number;
    precioTotal: number;
    name: string
}