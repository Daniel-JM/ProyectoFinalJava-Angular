export class Articulos {
    id?: number
    name: string = ""
    price: number
    stock: number
    image?: string = "http://placekitten.com/200/200"   
    cantidad?: number = 1
    pedido?: number
    
}