import { Pedidos } from "./pedidos"

export class Usuarios {
    id?: number
    name: string
    password: string
    image?:string="http://placekitten.com/200/100"
    cantidad?:number = 1 
    
}