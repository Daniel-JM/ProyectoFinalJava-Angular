import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Usuarios } from '../clases/usuarios';
import { Articulos } from '../clases/articulos';
import { Pedidos } from '../clases/pedidos';
import { Cantidad } from '../clases/cantidad';

@Injectable({
  providedIn: 'root'
})
export class appService {
  usuarioLogeado: Usuarios;
  pedido: Pedidos;

  constructor(private http: HttpClient) {
  }

  //cantidad



  getUsuarios(): Observable<Array<Usuarios>> {
    return this.http.get<Array<Usuarios>>(`${environment.BACKEND_URL}/usuarios`)
  }

  addUsuario(usuario: Usuarios): Observable<Usuarios> {
    return this.http.post<Usuarios>(`${environment.BACKEND_URL}/usuarios`, usuario, httpOptions)
  }

  deleteUsuario(id: number) {
    return this.http.delete<Usuarios>(`${environment.BACKEND_URL}/usuarios/${id}`)
  }

  updateUsuario(usuario: Usuarios) {
    const url = `${environment.BACKEND_URL}/usuarios/${usuario.id}`;
    return this.http.put<Usuarios>(url, usuario, httpOptions);
  }

  getOneUsuario(usuario: Usuarios): Observable<{}> {
    const url = `${environment.BACKEND_URL}/usuarios/${usuario.id}`;
    return this.http.get(url)
  }

  //articulos  

  getArticulos(): Observable<Array<Articulos>> {
    return this.http.get<Array<Articulos>>(`${environment.BACKEND_URL}/articulos`)
  }

  addArticulo(articulo: Articulos): Observable<Articulos> {
    return this.http.post<Articulos>(`${environment.BACKEND_URL}/articulos`, articulo, httpOptions)
  }

  deleteArticulo(id: number) {
    return this.http.delete<Articulos>(`${environment.BACKEND_URL}/articulos/${id}`)
  }

  updateArticulo(articulos: Articulos) {
    const url = `${environment.BACKEND_URL}/articulos/${articulos.id}`;
    return this.http.put<Articulos>(url, articulos, httpOptions);
  }

  getOneArticulo(articulos: Articulos): Observable<{}> {
    const url = `${environment.BACKEND_URL}/articulos/${articulos.id}`;
    return this.http.get(url)
  }

  //pedidos


  addPedido(pedido: Pedidos) {
    return this.http.post<Pedidos>(`${environment.BACKEND_URL}/pedidos`, pedido, httpOptions)
  }

  //clase cantidad
  addCantidad(cantidad: Cantidad) {
    return this.http.post<Cantidad>(`${environment.BACKEND_URL}/cantidad`, cantidad, httpOptions)
  }

  getCantidad(): Observable<Array<Cantidad>> {
    return this.http.get<Array<Cantidad>>(`${environment.BACKEND_URL}/cantidad`)
  }

  setPedidosCantidad(cantidad: Cantidad) {
    this.pedido.listaArti.push(cantidad);
  }

  getPedidos(): Observable<Array<Pedidos>> {
    return this.http.get<Array<Pedidos>>(`${environment.BACKEND_URL}/pedidos`)
  }

  deletePedido(id: number) {
    return this.http.delete<Pedidos>(`${environment.BACKEND_URL}/pedidos/${id}`)
  }

  updatePedido(pedido: Pedidos) {
    const url = `${environment.BACKEND_URL}/pedidos/${pedido.id}`;
    return this.http.put<Articulos>(url, pedido, httpOptions);
  }

  getOnePedido(pedido: Pedidos): Observable<{}> {
    const url = `${environment.BACKEND_URL}/'pedidos'/${pedido.id}`;
    return this.http.get(url)
  }





}

const httpOptions = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};

